'use strict';
import ReactDOM from 'react-dom'
import React from 'react'
import ScrollDetector from './ScrollDetector'

var body = (
  <ScrollDetector/>
);

ReactDOM.render(
  body,
  document.getElementById('container')
);
